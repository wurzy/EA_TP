package backend.dao; /**
 * "Visual Paradigm: DO NOT MODIFY THIS FILE!"
 * 
 * This is an automatic generated file. It will be regenerated every time 
 * you generate persistence class.
 * 
 * Modifying its content may cause the program not work, or your work may lost.
 */

/**
 * Licensee: Filipa Santos(Universidade do Minho)
 * License Type: Academic
 */
public interface ORMConstants extends org.orm.util.ORMBaseConstants {
	final int KEY_COMMENTS_IDPOST = 825954534;
	
	final int KEY_COMMENTS_IDUSER = 826106897;
	
	final int KEY_FILES_IDRESOURCE = -1372559055;
	
	final int KEY_POSTS_COMMENTS = -1962410752;
	
	final int KEY_POSTS_IDRESOURCE = -1077578155;
	
	final int KEY_POSTS_IDUSER = -417670766;
	
	final int KEY_RATINGS_IDRESOURCE = 1581216722;
	
	final int KEY_RATINGS_IDUSER = -360637041;
	
	final int KEY_RESOURCES_FILES = -225795139;
	
	final int KEY_RESOURCES_IDRESOURCETYPE = -1682454883;
	
	final int KEY_RESOURCES_POSTS = -216373991;
	
	final int KEY_RESOURCES_RATINGS = -402181572;
	
	final int KEY_RESOURCES_UPDATES = -1620209520;
	
	final int KEY_RESOURCETYPES_RESOURCES = -1777449999;
	
	final int KEY_ROLES_USERS = -1845598746;
	
	final int KEY_UPDATES_IDRESOURCE = -333670146;
	
	final int KEY_UPDATES_IDUSER = -122177349;
	
	final int KEY_USERS_COMMENTS = 417896043;
	
	final int KEY_USERS_IDROLE = -594057624;
	
	final int KEY_USERS_POSTS = 1511681724;
	
	final int KEY_USERS_RATINGS = -1892983009;
	
	final int KEY_USERS_UPDATES = 1183956339;

	final int KEY_RESOURCES_USERS = -1263936439;
}

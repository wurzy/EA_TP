package backend.json;

public class TypesJSON {
    private String[] types;

    public TypesJSON(String[] type) {
        this.types = type;
    }

    public String[] getTypes() {
        return types;
    }
}
